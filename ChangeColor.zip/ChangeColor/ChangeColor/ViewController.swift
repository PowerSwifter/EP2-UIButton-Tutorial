//
//  ViewController.swift
//  ChangeColor
//
//  Created by 後F on 2016/10/20.
//  Copyright © 2016年 後F. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var characterLabel: UILabel!
    
    @IBAction func changeColor(_ sender: UIButton) {
        
        characterLabel.textColor = UIColor.white
        
        sender.setTitleColor(UIColor.blue, for: .normal)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

